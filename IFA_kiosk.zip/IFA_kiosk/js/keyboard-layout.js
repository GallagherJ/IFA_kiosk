// symbol: The character or word to be inserted to
Keyboard.layout.number = [
  [
    {"symbol": "7"},
    {"symbol": "8"},
    {"symbol": "9"},
    {"label": "\u21E6", "symbol": "backspace"}
  ],
  [
    {"label": "+/-", "symbol": "flipSign"},
    {"symbol": "4"},
    {"symbol": "5"},
    {"symbol": "6"}
  ],
  [
    {"symbol": "0"},
    {"symbol": "1"},
    {"symbol": "2"},
    {"symbol": "3"}
  ]
];
